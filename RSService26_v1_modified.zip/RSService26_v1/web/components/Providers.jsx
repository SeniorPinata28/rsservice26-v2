'use client';
import { CartProvider } from './cart-store';
export default function Providers({children}){return <CartProvider>{children}</CartProvider>}
