import { PrismaClient } from '@prisma/client';
import fs from 'fs';
const prisma = new PrismaClient();
const parts = JSON.parse(fs.readFileSync('./data/parts.json','utf-8'));
for (const p of parts) { await prisma.part.upsert({ where:{sku:p.sku}, update:p, create:p }); }
console.log('Seed complete:', parts.length, 'parts');
await prisma.$disconnect();
