import './globals.css';
import Providers from '../components/Providers';
export const metadata={title:'RSService26 — Hyundai/Kia сервис и запчасти',description:'Запись на сервис Hyundai/Kia в Ставрополе, каталог запчастей, корзина и оформление заказов.'};
export default function RootLayout({children}){return <html lang='ru'><body><Providers>{children}</Providers></body></html>}
