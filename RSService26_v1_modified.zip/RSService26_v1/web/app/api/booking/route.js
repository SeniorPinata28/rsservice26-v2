import { NextResponse } from 'next/server';import { z } from 'zod';import { prisma } from '../../../lib/prisma';import { notifyEmail, notifyTelegram } from '../../../lib/notify';const schema=z.object({name:z.string().min(2),phone:z.string().min(5),brand:z.string(),model:z.string(),date:z.string(),time:z.string(),service:z.string()});export async function POST(req){try{const data=schema.parse(await req.json());const booking=await prisma.booking.create({data});const text=`Новая запись #${booking.id}
${booking.name}
${booking.phone}
${booking.brand} ${booking.model}
${booking.date} ${booking.time}
${booking.service}`;await notifyTelegram(text);await notifyEmail(`Новая запись #${booking.id}`,text);return NextResponse.json({ok:true,booking})}catch(e){return NextResponse.json({error:e.message},{status:400})}}
