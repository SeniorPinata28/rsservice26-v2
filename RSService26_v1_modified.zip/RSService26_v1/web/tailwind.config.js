export default { content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'], theme: { extend: { colors: { primary: '#1E63FF', dark: '#1F2937' } } }, plugins: [] };
